package bdqn.test06;

public class Runner implements Runnable{
    private int lenght = 10000;

    @Override
    public void run() {
        //使用同步方法 避免多人同时抢接力棒
        while (true){
            if(!baton())
                break;
        }
    }
    public synchronized boolean baton(){
        if(lenght<=0)
            return false;
        System.out.println(Thread.currentThread().getName() + "获得了接力棒");
        for(int i=1;i<=10;i++){
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(Thread.currentThread().getName() + "跑了" + i * 10 + "米!");
        }
        lenght-=100;
        //跑完后进行礼让
        Thread.currentThread().yield();
        return true;
    }

}
