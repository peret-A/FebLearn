package bdqn.test06;

public class Test {
    public static void main(String[] args) {
        //创建Runner类
        Runner runner =new Runner();
        //创建四个线程
        Thread thread1 =new Thread(runner,"1号选手");
        Thread thread2 =new Thread(runner,"2号选手");
        Thread thread3 =new Thread(runner,"3号选手");
        Thread thread4 =new Thread(runner,"4号选手");
        //启动线程
        thread1.start();
        thread2.start();
        thread3.start();
        thread4.start();
    }
}
