package bdqn.test05;

public class MyOrdinaryRunnable implements Runnable{
    @Override
    public void run() {
    //某科室一天需看普通号50个
        for(int i=1;i<=50;i++){
            if(i==10){
                //需要经行阻塞行为
                try {
                    Thread.currentThread().join();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            System.out.println(Thread.currentThread().getName()+":"+ i + "号病人在看病!");
            //看病时间
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
