package bdqn.test05;

public class MySpecialRunnable implements Runnable{
    @Override
    public void run() {
        //某科室一天需看特需号10个
        for(int i=1;i<=10;i++){
            System.out.println(Thread.currentThread().getName()+":" + i + "号病人在看病!");
            //看病时间
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
