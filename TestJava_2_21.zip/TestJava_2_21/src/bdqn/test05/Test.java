package bdqn.test05;

public class Test {
    /*
    某科室一天需看普通号50个，特需号10个
    特需号看病时间是普通号的2倍
    开始时普通号和特需号并行叫号，叫到特需号的概率比普通号高
    当普通号叫完第10号时，要求先看完全部特需号，再看普通号
    使用多线程模拟这一过程
     */
    public static void main(String[] args) {
        //创建2个线程
        Thread thread1 =Thread.currentThread();
        Thread thread2 = new Thread(new MySpecialRunnable(),"特需号");
        //设置普通房名字
        thread1.setName("普通房");
        //提高特需要房的概率
        thread2.setPriority(6);
        //启动线程
        thread2.start();
        for(int i=1;i<=50;i++){
            if(i==11){
                //需要经行阻塞行为
                try {
                    thread2.join();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            System.out.println(Thread.currentThread().getName()+":"+ i + "号病人在看病!");
            //看病时间
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }

    }
}
