package bdqn.test01;

public class Test {
    public static void main(String[] args) {
        /*
        创建线程类MyThread，并继承Thread类
        重写Thread类中的run()方法，编写方法体
        在测试类Test类中创建两个MyThread类的线程对象
        调用start()方法启动
        运行程序，观察多个线程交替执行的结果
         */
        //创建MyThread类
        MyThread myThread1 =new MyThread();
        MyThread myThread2 =new MyThread();
        //修改名字
        myThread1.setName("线程A");
        myThread2.setName("线程B");
        //启动线程
        myThread1.start();
        myThread2.start();
    }
}
