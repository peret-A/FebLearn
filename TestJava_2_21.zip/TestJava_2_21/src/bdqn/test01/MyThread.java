package bdqn.test01;

public class MyThread extends Thread{
    @Override
    public void run() {
        for(int i=1;i<=20;i++){
            System.out.println(Thread.currentThread().getName()+" 正在抢占cpu资源: "+i+"次");
        }
    }
}
