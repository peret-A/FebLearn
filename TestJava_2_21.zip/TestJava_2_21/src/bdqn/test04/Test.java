package bdqn.test04;

public class Test {
    public static void main(String[] args) {
        /*
        显示主线程、子线程默认优先级
        将主线程设置为最高优先级、子线程设置为最低优先级并显示
         */
        //创建主线程 与子线程
        Thread thread1 =Thread.currentThread();
        Thread thread2 =new Thread();
        //获取主线程、子线程优先级
        System.out.println("显示默认优先级");
        System.out.println("主线程名：" + thread1.getName() + ",优先级：" + thread1.getPriority());
        System.out.println("主线程名：" + thread2.getName() + ",优先级：" + thread2.getPriority());
        //修改主线程、子线程优先级
        System.out.println("修改默认优先级后");
        System.out.println("主线程名：" + thread1.getName() + ",优先级：" + thread1.getPriority());
        System.out.println("主线程名：" + thread2.getName() + ",优先级：" + thread2.getPriority());
    }
}
