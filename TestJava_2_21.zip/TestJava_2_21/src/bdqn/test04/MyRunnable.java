package bdqn.test04;

public class MyRunnable implements Runnable{
    @Override
    public void run() {

    }
}
