package bdqn.test08;

public class Main {
    public static void main(String[] args) {
        TicketGrabbingSystem system = new TicketGrabbingSystem();

        // 创建“桃跑跑”、“张票票”、“黄牛党”线程
        Thread peachRunner = new Thread(() -> {
            while (system.grabTicket("桃跑跑")) {
                // 抢票逻辑
            }
        });

        Thread ticketMaster = new Thread(() -> {
            while (system.grabTicket("张票票")) {
                // 抢票逻辑
            }
        });

        Thread scalper = new Thread(() -> {
            while (system.grabTicket("黄牛党")) {
                // 抢票逻辑
            }
        });

        // 启动线程
        peachRunner.start();
        ticketMaster.start();
        scalper.start();
    }
}
