package bdqn.test08;

import java.util.HashSet;
import java.util.Set;

public class TicketGrabbingSystem extends Thread{
    private static final int TOTAL_TICKETS = 10;
    private int availableTickets = TOTAL_TICKETS;
    private Set<String> grabbedByScalpers = new HashSet<>(); // 用于记录“黄牛党”已经抢到的票

    @Override
    public void run() {
        grabTicket(Thread.currentThread().getName());
    }

    // 抢票方法
    public synchronized boolean grabTicket(String userType) {
        if (userType.equals("黄牛党")) {
            // “黄牛党”只能抢一张票
            if (grabbedByScalpers.contains(userType)) {
                return false; // 如果已经抢到票则不能再抢
            } else {
                grabbedByScalpers.add(userType);
            }
        }

        if (availableTickets > 0) {
            availableTickets--;
            return true; // 抢票成功
        } else {
            return false; // 票已抢完
        }
    }

    // 获取剩余票数的方法
    public synchronized int getAvailableTickets() {
        return availableTickets;
    }
}
