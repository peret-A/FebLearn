package bdqn.test07;

public class Site implements Runnable{
    private int num=10;
    private int count=0;

    @Override
    public void run() {
        while (true){
        //采用同步代码
        synchronized (this){
            if(num<=0){
                break;
            }
                num--;
                count++;
                System.out.println(Thread.currentThread().getName() + "抢到了第" + count + "张票，剩余" + num + "张票!");
                //模拟网络延迟
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
                break;
            }
            Thread.yield();
            //判断是否为黄牛买的，是的话就中断
                if(Thread.currentThread().getName().equals("黄牛党")){
                    Thread.currentThread().interrupt();
                }

            }
        }
    }
}

