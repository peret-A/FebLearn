package bdqn.test07;

public class Test {
    public static void main(String[] args) {
        /*
        “桃跑跑”、“张票票”、“黄牛党”共同抢10张票
        限“黄牛党”只能抢一张票

         */
        //创建Site类
        Site site =new Site();
        //创建三个线程
        Thread thread1 =new Thread(site,"桃跑跑");
        Thread thread2 =new Thread(site,"张票票");
        Thread thread3 =new Thread(site,"黄牛党");
        //启动线程
        thread1.start();
        thread2.start();
        thread3.start();

    }
}
