package bdqn.test03;


public class Test {
    public static void main(String[] args) {
        //创建MyRunnable类
        MyRunnable myRunnable =new MyRunnable();
        //通过myRunnable对象创建青年人与老年人
        // 创建Thread类
        Thread thread1 = new Thread(myRunnable,"青年人");
        Thread thread2 = new Thread(myRunnable,"老年人");
        //启动线程
        thread1.start();
        thread2.start();
    }
}
