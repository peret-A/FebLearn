package com.bdqn.test01;

public class Test01 {
    public static void main(String[] args) {
        //获取线程Thread类
        //Thread() 分配新的 Thread 对象。
        // Thread(Runnable target) 分配新的 Thread 对象。
        // Thread(Runnable target, String name) 分配新的 Thread 对象。
        // Thread(String name) 分配新的 Thread 对象。
        // Thread(ThreadGroup group, Runnable target) 分配新的 Thread 对象。
        // Thread(ThreadGroup group, Runnable target, String name)分配新的 Thread 对象，以便将 target 作为其运行对象，将指定的 name 作为其名称，并作为 group 所引用的线程组的一员。
        // Thread(ThreadGroup group, Runnable target, String name, long stackSize)分配新的 Thread 对象，以便将 target 作为其运行对象，将指定的 name 作为其名称，作为 group 所引用的线程组的一员，并具有指定的堆栈大小。
        // Thread(ThreadGroup group, String name) 分配新的 Thread 对象。
        //static Thread currentThread()  返回对当前正在执行的线程对象的引用。
        Thread thread =Thread.currentThread();
        //获取线程名称
        System.out.println(thread.getName());
        //获取线程优先级
        System.out.println(thread.getPriority());
        //获取线程状态
        System.out.println(thread.getState());
        //测试tostring方法
        System.out.println(thread.toString());
    }
}
