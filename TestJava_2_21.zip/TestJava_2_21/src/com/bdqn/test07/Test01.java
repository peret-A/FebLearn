package com.bdqn.test07;

import java.util.ArrayList;
import java.util.LinkedList;

public class Test01 {
    public static void main(String[] args) {
        //创建三个节点
        ListNode listNode1 =new ListNode(1);
        ListNode listNode2 =new ListNode(2);
        ListNode listNode3 =new ListNode(3);
        //链接节点
        listNode1.next=listNode2;
        listNode2.next=listNode3;
        listNode1.Print();
        ArrayList<ListNode> arrayList =new ArrayList<>();
        ListNode listNode =listNode1;
        while (listNode!=null){
            arrayList.add(listNode);
            listNode=listNode.next;
        }
        listNode=arrayList.get(arrayList.size()-1);
        //反向遍历
        for(int i=arrayList.size()-2;i>=0;i--){
            listNode.next=arrayList.get(i);
            listNode=listNode.next;
        }
        arrayList.get(0).next=null;
        listNode3.Print();
    }
}
