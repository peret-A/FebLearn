package com.bdqn.test07;

public class ListNode {
    int val;
    ListNode next =null;
    ListNode(int val){
        this.val = val;
    }
    public void Print(){
        ListNode listNode =this;
        while (listNode!=null){
            System.out.println(listNode.val);
            listNode=listNode.next;
        }
    }

}
