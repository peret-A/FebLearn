package com.bdqn.test06;

public class MyRunnable implements Runnable{
    private int num=100;
    private int count =0;

    @Override
    public void run() {
        while (true){
        if(!sale()){
            break;
        }
    }
    }
    public synchronized boolean sale(){
        if(num<=0){
            return false;
        }
        num--;
        count++;
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println(Thread.currentThread().getName() + "抢到了第" + count + "张票，剩余" + num + "张");
        return true;
    }
}
