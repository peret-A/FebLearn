package com.bdqn.test06;



public class Test {
    public static void main(String[] args) {
        //创建MyRunnable类
        MyRunnable myRunnable = new MyRunnable();
        Thread thread1 =new Thread(myRunnable,"张三");
        Thread thread2 =new Thread(myRunnable,"李四");
        Thread thread3 =new Thread(myRunnable,"王五");
        thread1.start();
        thread2.start();
        thread3.start();

    }
}
