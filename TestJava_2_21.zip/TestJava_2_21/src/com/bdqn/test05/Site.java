package com.bdqn.test05;

public class Site implements Runnable{
    private int num = 10;
    private int count = 0;
    @Override
    public  void run() {

        while(true){
            if(num<=0){
                break;
            }
            sale();
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(Thread.currentThread().getName() + "抢到第" + count + "张，剩余" + num + "票");
        }
    }
    public synchronized boolean sale(){
        num--;
        count++;
        return num==0?true:false;
    }
}
