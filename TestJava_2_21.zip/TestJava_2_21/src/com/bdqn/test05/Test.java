package com.bdqn.test05;

public class Test {
    public static void main(String[] args) {
        //创建Site类
        Site site =new Site();
        //创建线程
        Thread thread1 =new Thread(site,"张三");
        Thread thread2 =new Thread(site,"李四");
        Thread thread3 =new Thread(site,"王五");
        //启动线程
        thread1.start();
        thread2.start();
        thread3.start();
    }
}
