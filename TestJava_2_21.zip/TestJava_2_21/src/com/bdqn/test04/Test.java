package com.bdqn.test04;

public class Test {
    public static void main(String[] args) {
        //创建MyRunnable类
        MyRunnable myRunnable =new MyRunnable();
        //创建进程1 和进程2
        Thread thread1 =new Thread(myRunnable,"进程A");
        Thread thread2 =new Thread(myRunnable,"进程B");
        //启动线程
        thread1.start();
        thread2.start();
    }
}
