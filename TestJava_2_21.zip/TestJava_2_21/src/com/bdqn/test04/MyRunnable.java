package com.bdqn.test04;

public class MyRunnable implements Runnable{
    @Override
    public void run() {
        for(int i=1;i<=20;i++){
            System.out.println(Thread.currentThread().getName() + "正在执行: " + i);
//            if(i==10){
//                //如果i==10时，进行礼让，即与其他进程重新抢占cpu
//                Thread.yield();
//
//            }
            if(i==10){
                //如果i==10时，进程休眠5s
                try {
                    System.out.println("进行休眠...");
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
