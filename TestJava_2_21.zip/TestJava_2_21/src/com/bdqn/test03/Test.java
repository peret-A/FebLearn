package com.bdqn.test03;

public class Test {
    public static void main(String[] args) {
        //获取线程
        MyRunnable myRunnable =new MyRunnable();
        Thread thread1 = new Thread(myRunnable);
//        Thread thread2 = new Thread(myRunnable,"线程B");
        thread1.start();
//        thread2.start();
        //因为Runnable类不存在start方法， 所以只能调用run方法但是run方法又是只能主线程执行，所以我们通过Thread（Runnbale,String）方法创建线程

    }
}
