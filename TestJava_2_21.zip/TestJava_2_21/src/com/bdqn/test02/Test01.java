package com.bdqn.test02;

public class Test01 {
    public static void main(String[] args) {
        //使用主线程
        for(int i=1;i<=100;i++){
            System.out.println(Thread.currentThread().getName() + "正在执行: " + i + "次数");
        }
        //定义线程
        MyThread myThread1 =new MyThread();
        MyThread myThread2 =new MyThread();
        //修改线程名称
        myThread1.setName("线程A");
        myThread2.setName("线程B");
        //如果直接用run方法
//        myThread.run();
        //结果是主线程直接执行
        //用自己定义的线程应使用start方法
        myThread1.start();
        myThread2.start();
    }
}
