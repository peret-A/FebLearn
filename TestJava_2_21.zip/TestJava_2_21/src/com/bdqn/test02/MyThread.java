package com.bdqn.test02;

public class MyThread extends Thread{
    @Override
    public void run() {
        for(int i=1;i<=50;i++){
            System.out.println(Thread.currentThread().getName() + "正在执行: " + i + "次数");
        }
    }
}
