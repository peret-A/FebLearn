package com.bdqn.test01;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class RestaurantLogin {
/**
 * @author liuziyang
 * @data 2024-02-22-18:58
 */

public static void enroll(){
    //创建Scanner类
    Scanner scanner =new Scanner(System.in);
    System.out.print("输入用户名: ");
    String root =scanner.next();
    //先将数据从文件中读取出来
    //再将注册成功的账号写入进去
    InputStream inputStream=null;
    ObjectInputStream objectInputStream =null;
    OutputStream outputStream =null;
    ObjectOutputStream objectOutputStream =null;
    try {
            inputStream =new FileInputStream("User.txt");
            objectInputStream=new ObjectInputStream(inputStream);
            //用户名唯一
            //将数据读取出来
        ArrayList<User> userArrayList =new ArrayList<>();
            User userData=null;
            while ((userData= (User) objectInputStream.readObject())!=null){
                userArrayList.add(userData);

            }
            for(User user:userArrayList){
                if(root.equals(user.getRoot())){
                    //判断如果用户名相同就结束
                    System.out.println("用户名已存在!");
                    objectInputStream.close();
                    inputStream.close();
                    return;

            }

        }
            outputStream =new FileOutputStream("User.txt");
            objectOutputStream=new ObjectOutputStream(outputStream);
        //执行到这里说明用户名唯一
        //创建User类
        User user = new User();
        user.setRoot(root);
        System.out.print("输入密码: ");
        user.setPwd(scanner.next());
        System.out.print("输入用户名称: ");
        user.setName(scanner.next());
        System.out.print("输入地址: ");
        user.setAdder(scanner.next());
        //写入文件中
        userArrayList.add(user);
        for(User user1:userArrayList){
            objectOutputStream.writeObject(user1);
        }
        objectOutputStream.writeObject(null);
        objectOutputStream.flush();

    } catch (FileNotFoundException e) {
        throw new RuntimeException(e);
    } catch (IOException e) {
        throw new RuntimeException(e);
    } catch (ClassNotFoundException e) {
        throw new RuntimeException(e);
    }finally {
        //关闭流
        if(objectOutputStream!=null){
            try {
                objectOutputStream.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        if(outputStream!=null){
            try {
                outputStream.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        if(objectInputStream!=null){
            try {
                objectInputStream.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        if(inputStream!=null){
            try {
                inputStream.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}

    public static void login() {
    //读取文件判断输入的用户名与密码是否匹配
    //创建读取流
        InputStream inputStream=null;
        ObjectInputStream objectInputStream =null;
        try {
            File file =new File("User.txt");
            //判断文件是否为空
            if(file.length()==0){
                //说明User文件不存在数据 直接结束
                System.out.println("不存在用户，请先注册一个");
                return;
            }
            inputStream =new FileInputStream("User.txt");
            objectInputStream =new ObjectInputStream(inputStream);
            //输入用户名 密码
            // 创建Scanner对象
            Scanner scanner =new Scanner(System.in);
            System.out.print("输入用户名: ");
            String root =scanner.next();
            System.out.print("输入密码: ");
            String pwd = scanner.next();

            //读取文件数据
            //创建User类
            User userData;
            while ((userData=(User)objectInputStream.readObject())!=null){
                if(root.equals(userData.getRoot())&&pwd.equals(userData.getPwd())){
                    //如果判断成功说明登录成功
                    break;
                }
            }
            if(userData==null){
                //user是空就说明 登录失败
                System.out.println("登录失败,用户名或者密码错误");
                return;
            }
            int input;
            do {
                //进入子菜单
                RestaurantMean.submenu();
                System.out.print("请输入你的选择: ");
                input=scanner.nextInt();
                switch (input){
                    case 0:
                        return;
                    case 1:orderFoot(userData); //订餐
                        break;
                    case 2:check();//查看订单
                        break;
                    case 3:sign();//签收订单
                        break;
                    case 4:dele();//删除订单
                        break;
                    case 5:like();//点赞餐品
                        break;
                    default:
                        System.out.println("选择错误，重新选择");
                        break;

                }
            }while (input!=0);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }finally {
            //关闭流
            if(objectInputStream!=null){
                try {
                    objectInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(inputStream!=null){
                try {
                    inputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    private static void like() {
        System.out.println("---------- 点赞餐品 -----------");
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        check();
        int id;
        System.out.print("请输入要点赞的订单序号: ");
        id =scanner.nextInt();
        //创建读取订单文件 读取菜单文件 写入菜单文件
        InputStream orderInputStream =null;
        ObjectInputStream orderObecjInputStream =null;
        InputStream mealInputStream =null;
        ObjectInputStream mealObjectInputStream =null;
        OutputStream mealOutputStream =null;
        ObjectOutputStream mealObjectOutputStream =null;
        try {
            orderInputStream =new FileInputStream("Order.txt");
            orderObecjInputStream =new ObjectInputStream(orderInputStream);
            //创建Order集合
            ArrayList<Order> orderArrayList =new ArrayList<>();
            //创建Order类
            Order order =null;
            while ((order=(Order) orderObecjInputStream.readObject())!=null){
                orderArrayList.add(order);
            }
            if(id>orderArrayList.size()&&id<=0){
                System.out.println("该订单不存在");
                orderObecjInputStream.close();
                orderInputStream.close();
                return;
            }
            //通过订单文件去找到序号id对应的餐品
            //创建餐品名
            String name=orderArrayList.get(id-1).getMname();

            mealInputStream =new FileInputStream("Meal.txt");
            mealObjectInputStream =new ObjectInputStream(mealInputStream);
            //创建菜单列表
            ArrayList<Meal> mealArrayList =new ArrayList<>();
            Object object =null;
            while ((object=mealObjectInputStream.readObject())!=null){
                mealArrayList.add((Meal) object);
            }

            //以重新写入方法写入
            mealOutputStream =new FileOutputStream("Meal.txt");
            mealObjectOutputStream =new ObjectOutputStream(mealOutputStream);

            for(Meal meal1:mealArrayList){
                if(meal1.getName().equals(name)){
                    meal1.setLikes(meal1.getLikes());
                }
            }
            for(Meal meal1:mealArrayList){
                mealObjectOutputStream.writeObject(meal1);
            }
            mealObjectOutputStream.writeObject(null);
            mealObjectOutputStream.flush();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }finally {
            //关闭流
            if(mealObjectOutputStream!=null){
                try {
                    mealObjectOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(mealOutputStream!=null){
                try {
                    mealOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(mealObjectInputStream!=null){
                try {
                    mealObjectInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(mealInputStream!=null){
                try {
                    mealInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(orderObecjInputStream!=null){
                try {
                    orderObecjInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(orderInputStream!=null){
                try {
                    orderInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    private static void dele() {
        System.out.println("---------- 删除订单 -----------");
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        check();
        int id;
        System.out.print("请输入订单的序号: ");
        id =scanner.nextInt();
        //读取并写入Order文件
        InputStream inputStream=null;
        ObjectInputStream objectInputStream=null;
        OutputStream outputStream =null;
        ObjectOutputStream objectOutputStream =null;
        try {
            inputStream=new FileInputStream("Order.txt");
            objectInputStream=new ObjectInputStream(inputStream);

            //读取文件判断是否存在id序号的订单
            //创建Order类
            ArrayList<Order> orderArrayList =new ArrayList<>();
            Order order=null;
            while ((order=(Order) objectInputStream.readObject())!=null){
                orderArrayList.add(order);
            }
            if(id>orderArrayList.size()&&id<=0){
                System.out.println("该订单不存在");
                objectInputStream.close();
                inputStream.close();
                return;
            }
            orderArrayList.remove(id-1);
            int count =1;
            for(Order order1:orderArrayList){
                order1.setId(count);
                count++;
            }
            //以重新写入的方法写入
            outputStream =new FileOutputStream("Order.txt");
            objectOutputStream=new ObjectOutputStream(outputStream);
            for(Order order1:orderArrayList){
                objectOutputStream.writeObject(order1);
            }
            objectOutputStream.writeObject(null);
            objectOutputStream.flush();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }finally {
            //关闭流
            if(objectOutputStream!=null){
                try {
                    objectOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(outputStream!=null){
                try {
                    outputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(objectInputStream!=null){
                try {
                    objectInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(inputStream!=null){
                try {
                    inputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    private static void sign() {
        System.out.println("---------- 签收订单 -----------");
    //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        check();
        int id;
        System.out.print("请输入订单的序号: ");
        id =scanner.nextInt();
        //读取并写入Order文件
        InputStream inputStream=null;
        ObjectInputStream objectInputStream=null;
        OutputStream outputStream =null;
        ObjectOutputStream objectOutputStream =null;
        try {
            inputStream=new FileInputStream("Order.txt");
            objectInputStream=new ObjectInputStream(inputStream);
            //读取文件判断是否存在id序号的订单
            //创建Order类
            //创建计数器
            int count=0;
            Order order=null;
            ArrayList<Order> orderArrayList =new ArrayList<>();
            while ((order=(Order) objectInputStream.readObject())!=null){
                orderArrayList.add(order);
            }
            if(id>orderArrayList.size()&&id<=0){
                System.out.println("该订单不存在");
                objectInputStream.close();
                inputStream.close();
                return;
            }
            //以重新写入的方法写入
            outputStream =new FileOutputStream("Order.txt");
            objectOutputStream=new ObjectOutputStream(outputStream);
            for(Order order1:orderArrayList){
                if(id==order1.getId()){
                    //匹配成功 判断订单是否为已预定
                    if(order1.getState().equals("已预定")){
                        //如果是 就将状态变成已完成
                        order1.setState("已完成");
                    }else{
                        //如果不是，就是说明订单早已签收
                        System.out.println("该订单早已签收！");
                    }
                }
                objectOutputStream.writeObject(order1);
            }
            objectOutputStream.writeObject(null);
            objectOutputStream.flush();
            if(count>id){
                //说明id不存在
                System.out.println("该订单不存在,请重新确认");
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }finally {
            //关闭流
            if(objectOutputStream!=null){
                try {
                    objectOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(outputStream!=null){
                try {
                    outputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(objectInputStream!=null){
                try {
                    objectInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(inputStream!=null){
                try {
                    inputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public static void orderFoot(User user){
        System.out.println("---------- 订餐 -----------");
        RestaurantMean.mealMean();
        //读取Meal文件 User文件
        //写入到Order文件
        InputStream mealInputStream=null;
        ObjectInputStream mealObjectInputStream=null;
        InputStream orderInputStream =null;
        ObjectInputStream orderObjectInputStream =null;
        OutputStream orderOutputStream=null;
        ObjectOutputStream orderObjectOutputStream =null;
        try {
            mealInputStream =new FileInputStream("Meal.txt");
            mealObjectInputStream=new ObjectInputStream(mealInputStream);
            orderInputStream =new FileInputStream("Order.txt");
            orderObjectInputStream =new ObjectInputStream(orderInputStream);
                //创建Meal类
                //反序列化
                ArrayList<Meal> mealArrayList =new ArrayList<>();
                Meal meal;
                //匹配菜品
                while ((meal=(Meal) mealObjectInputStream.readObject())!=null) {
                    mealArrayList.add(meal);
                }
            //创建Scanner对象
            Scanner scanner =new Scanner(System.in);
            int id;
            while (true){
                System.out.print("请输入要订餐的序号: ");
                id =scanner.nextInt();
                if(id<=mealArrayList.size()&&id>0)
                    break;
            }
                //计算器
                int count=1;
            ArrayList<Order> orderArrayList = new ArrayList<>();
                //判断该订单是第几个订单
            //创建Order类
            Order orderData =null;
                while ((orderData=(Order) orderObjectInputStream.readObject())!=null) {
                    count++;
                    orderArrayList.add(orderData);
                }

            orderOutputStream=new FileOutputStream("Order.txt");
            orderObjectOutputStream=new ObjectOutputStream(orderOutputStream);
                //如果成功就说明菜品存在，并写入订单
                //创建Order类
                Order order =new Order();
                order.setId(count);
                order.setUname(user.getName());
                System.out.print("请输入要订餐的份数: ");
                order.setNum(scanner.nextInt());
                order.setMname(mealArrayList.get(id-1).getName());
                order.setMoney(mealArrayList.get(id-1).getPrice()*order.getNum());
                order.setState("已预定");
                DateFormat dateFormat =new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                order.setTime(dateFormat.getCalendar().getTime());
                orderArrayList.add(order);
                //写入订单文件
                //序列化
            for(Order order1:orderArrayList){
                orderObjectOutputStream.writeObject(order1);
            }
                orderObjectOutputStream.writeObject(null);
                orderObjectOutputStream.flush();

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }finally {
            if(orderObjectOutputStream!=null){
                try {
                    orderObjectOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(orderOutputStream!=null){
                try {
                    orderOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(orderObjectInputStream!=null){
                try {
                    orderObjectInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(orderInputStream!=null){
                try {
                    orderInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(mealObjectInputStream!=null){
                try {
                    mealObjectInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(mealInputStream!=null){
                try {
                    mealInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
    public static void check(){
        System.out.println("---------- 查看订单 -----------");
        //读取订单文件
        InputStream inputStream=null;
        ObjectInputStream objectInputStream =null;
        try {
            inputStream =new FileInputStream("Order.txt");
            objectInputStream=new ObjectInputStream(inputStream);
            //创建Order类
            //反序列化
            Order order =null;
            while ((order=(Order) objectInputStream.readObject())!=null){
                System.out.println(order);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }finally {
            //关闭流
            if(objectInputStream!=null){
                try {
                    objectInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(inputStream!=null){
                try {
                    inputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
