package com.bdqn.test01;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class RestaurantMean {
/**
 * @author liuziyang
 * @data 2024-02-22-19:07
 */
public static void mainMenu(){
    System.out.println("---------- 主系统 -----------");
    System.out.println(" 1. 登录 ");
    System.out.println(" 2. 注册 ");
    System.out.println(" 0. 退出 ");
}
public static void submenu(){
    System.out.println("---------- 子系统 -----------");
    System.out.println(" 1. 订餐 ");
    System.out.println(" 2. 查看订单 ");
    System.out.println(" 3. 签收订单 ");
    System.out.println(" 4. 删除订单 ");
    System.out.println(" 5. 点赞订单 ");
    System.out.println(" 0. 退出 ");
}
public static void mealMean(){
    System.out.println("---------- 菜单 -----------");
    //创建流
    InputStream inputStream=null;
    ObjectInputStream objectInputStream=null;
    try {
        inputStream =new FileInputStream("Meal.txt");
        objectInputStream = new ObjectInputStream(inputStream);
        ArrayList<Meal> mealArrayList =new ArrayList<>();
        //反序列化
        Object object =null;
        while ((object=objectInputStream.readObject())!=null){
            mealArrayList.add((Meal) object);
        }
        for(Meal meal:mealArrayList){
            System.out.println(meal);
        }
    } catch (FileNotFoundException e) {
        throw new RuntimeException(e);
    } catch (IOException e) {
        throw new RuntimeException(e);
    } catch (ClassNotFoundException e) {
        throw new RuntimeException(e);
    }
}

    public static void Init(){
        //创建用户文件 菜单文件 订单文件
        File userFile =new File("User.txt");
        File mealFile =new File("Meal.txt");
        File orderFile =new File("Order.txt");
        //用户文件 菜单文件 订单文件都存在是不需要初始化了
        if(userFile.exists()&&mealFile.exists()&&orderFile.exists()){
            return;
        }
        try {
            userFile.createNewFile();
            mealFile.createNewFile();
            orderFile.createNewFile();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        ArrayList<User> userArrayList=new ArrayList<>();
        User user =new User("admin","123","admin","2-311");
        userArrayList.add(user);

        ArrayList<Meal> mealArrayList =new ArrayList<>();
        Meal meal1 = new Meal(1,"小炒",21,13);
        Meal meal2 = new Meal(2,"红肠",8,13);
        Meal meal3 = new Meal(3,"烤鸭",16,13);
        Meal meal4 = new Meal(4,"土豆",4,13);
        Meal meal5 = new Meal(5,"地三鲜",30,13);
        Meal meal6 = new Meal(6,"红茶",12,13);
        Meal meal7 = new Meal(7,"绿茶",12,13);
        Meal meal8 = new Meal(8,"啤酒",8,13);
        Meal meal9 = new Meal(9,"红酒",134,13);
        mealArrayList.add(meal1);
        mealArrayList.add(meal2);
        mealArrayList.add(meal3);
        mealArrayList.add(meal4);
        mealArrayList.add(meal5);
        mealArrayList.add(meal6);
        mealArrayList.add(meal7);
        mealArrayList.add(meal8);
        mealArrayList.add(meal9);
        DateFormat dateFormat =new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        Calendar calendar =dateFormat.getCalendar();
        Order order =new Order(1,"admin","小炒",1,"已完成",calendar.getTime(),21);
        //写入初始用户文件 菜单文件 以 w 的方法写入
        OutputStream userOutputStream =null;
        ObjectOutputStream userObjectOutputStream =null;
        OutputStream outputStream =null;
        ObjectOutputStream objectOutputStream =null;
        OutputStream orderOutputStream =null;
        ObjectOutputStream orderObjectOutputStream=null;
        try {
            //创建写入流
            userOutputStream=new FileOutputStream("User.txt");
            userObjectOutputStream=new ObjectOutputStream(userOutputStream);
            outputStream = new FileOutputStream("Meal.txt");
            objectOutputStream = new ObjectOutputStream(outputStream);
            orderOutputStream = new FileOutputStream("Order.txt");
            orderObjectOutputStream =new ObjectOutputStream(orderOutputStream);
            //如果不写入一个null对象 ，则读取的时候会报异常EOFException ,则需要try catch 捕获异常   （已经注释）
            //写入文件
            for(User user1:userArrayList){
                userObjectOutputStream.writeObject(user1);
                userObjectOutputStream.flush();
            }
            userObjectOutputStream.writeObject(null);
            for(Meal meal:mealArrayList){
                objectOutputStream.writeObject(meal);
                objectOutputStream.flush();
            }
            objectOutputStream.writeObject(null);
            orderObjectOutputStream.writeObject(order);
            orderObjectOutputStream.writeObject(null);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }finally {
            if(orderObjectOutputStream!=null){
                try {
                    orderObjectOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(orderOutputStream!=null){
                try {
                    orderOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(objectOutputStream!=null){
                try {
                    objectOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(outputStream!=null){
                try {
                    outputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(userObjectOutputStream!=null){
                try {
                    userObjectOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(userOutputStream!=null){
                try {
                    userOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

        }

    }
}
