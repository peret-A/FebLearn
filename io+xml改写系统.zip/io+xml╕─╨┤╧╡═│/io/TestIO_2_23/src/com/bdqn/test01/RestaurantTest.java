package com.bdqn.test01;

import java.util.Scanner;

public class RestaurantTest {
/**
 * @author liuziyang
 * @data 2024-02-22-19:15
 */
public static void main(String[] args) {

    //创建Scanner对象
    Scanner scanner =new Scanner(System.in);

    //初始化用户文件 菜单文件 订单文件
    RestaurantMean.Init();
        int input;
        do {
            RestaurantMean.mainMenu();
            System.out.print("输入你的选择: ");
            input =scanner.nextInt();
            switch (input){
                case 0:System.exit(0);
                    break;
                case 1:
                    RestaurantLogin.login();
                    break;
                case 2:
                    RestaurantLogin.enroll();
                    break;
                default:
                    System.out.println("选择错误,重新选择");
                    break;
            }
        }while (input!=0);
}
}
