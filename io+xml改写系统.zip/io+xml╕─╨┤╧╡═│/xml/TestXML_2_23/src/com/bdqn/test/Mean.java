package com.bdqn.test;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Mean {
/**
 * @author liuziyang
 * @data 2024-02-23-17:07
 */
//用于存储 菜单 方法
public static void mainMenu(){
    System.out.println("---------- 主系统 -----------");
    System.out.println(" 1. 登录 ");
    System.out.println(" 2. 注册 ");
    System.out.println(" 0. 退出 ");
}

    public static void submenu(){
        System.out.println("---------- 子系统 -----------");
        System.out.println(" 1. 订餐 ");
        System.out.println(" 2. 查看订单 ");
        System.out.println(" 3. 签收订单 ");
        System.out.println(" 4. 删除订单 ");
        System.out.println(" 5. 点赞订单 ");
        System.out.println(" 0. 退出 ");
    }

public static void orderFoot(User user){
    System.out.println("---------- 订餐 -----------");
        //获取xml的餐品
    //读取meal.xml文件
//    1.创建解析器工厂对象
//    2.解析器工厂对象创建解析器对象
//    3.解析器对象指定XML文件创建Document对象
//    4.以Document对象为起点操作DOM树
    // # 解析XML文件并返回ElementTree对象
    DocumentBuilderFactory documentBuilderFactory =DocumentBuilderFactory.newDefaultInstance();
    try {
        DocumentBuilder db = documentBuilderFactory.newDocumentBuilder();
        Document document = db.parse("Meal.xml");
        //user元素
        NodeList nodeList = document.getElementsByTagName("meal");
        ArrayList<Meal> mealArrayList = new ArrayList<>();
        for (int i = 0; i < nodeList.getLength(); i++) {
            //创建Meal对象
            Meal meal = new Meal();
            //获取第i个user对象
            Node node = nodeList.item(i);
            //获取第i个user对象的属性值
            Element element = (Element) node;
            NodeList userNodeList = element.getChildNodes();
            for (int j = 0; j < userNodeList.getLength(); j++) {
                Node userNode = userNodeList.item(j);
                if (userNode.getNodeType() == Node.ELEMENT_NODE && userNode.getNodeName().equals("id")) {
                    Element userType = (Element) userNode;
                    meal.setId(Integer.valueOf(userType.getAttribute("name")));
                }
                if (userNode.getNodeType() == Node.ELEMENT_NODE && userNode.getNodeName().equals("name")) {
                    Element userType = (Element) userNode;
                    meal.setName(userType.getAttribute("name"));
                }
                if (userNode.getNodeType() == Node.ELEMENT_NODE && userNode.getNodeName().equals("price")) {
                    Element userType = (Element) userNode;
                    meal.setPrice(Double.valueOf(userType.getAttribute("name")));
                }
                if (userNode.getNodeType() == Node.ELEMENT_NODE && userNode.getNodeName().equals("likes")) {
                    Element userType = (Element) userNode;
                    meal.setLikes(Integer.valueOf(userType.getAttribute("name")));
                }
            }
            mealArrayList.add(meal);

        }
        //遍历
        for (Meal meal1 : mealArrayList) {
            System.out.println(meal1);
        }
        //创建Scanner对象
        Scanner scanner = new Scanner(System.in);
        int id;
        while (true) {
            System.out.print("请输入要订餐的序号: ");
            id = scanner.nextInt();
            if (id <= mealArrayList.size() && id > 0)
                break;
        }
        //计算器
        int count = 1;
        Document doc = db.parse("Order.xml");
        NodeList list = document.getElementsByTagName("order");
        int size = list.getLength()+1;
        //创建节点
        Element orderEle = doc.createElement("order");
        Element idELe = doc.createElement("id");
        Element unameELe =doc.createElement("Uname");
        Element MnameELe =doc.createElement("Mname");
        Element priceELe =doc.createElement("peice");
        Element stateELe =doc.createElement("state");
        orderEle.appendChild(idELe);
        orderEle.appendChild(unameELe);
        orderEle.appendChild(MnameELe);
        orderEle.appendChild(priceELe);
        orderEle.appendChild(stateELe);
        Element ordersEle =(Element) doc.getElementsByTagName("orders").item(0);
        ordersEle.appendChild(orderEle);

        //保存xml文件
        TransformerFactory transformerFactory =TransformerFactory.newInstance();
        Transformer transformer =transformerFactory.newTransformer();
        DOMSource docSourse =  new DOMSource(document);
        //设置编码类型
        transformer.setOutputProperty(OutputKeys.ENCODING,"utf-8");
        StreamResult result =new StreamResult(new FileOutputStream("User.xml"));
        transformer.transform(docSourse,result);
    } catch (ParserConfigurationException e) {
        throw new RuntimeException(e);
    } catch (IOException e) {
        throw new RuntimeException(e);
    } catch (SAXException e) {
        throw new RuntimeException(e);
    } catch (TransformerConfigurationException e) {
        throw new RuntimeException(e);
    } catch (TransformerException e) {
        throw new RuntimeException(e);
    }
}
public static void check(){
    System.out.println("---------- 查看订单 -----------");
    //获取xml的餐品
    //读取order.xml文件
//    1.创建解析器工厂对象
//    2.解析器工厂对象创建解析器对象
//    3.解析器对象指定XML文件创建Document对象
//    4.以Document对象为起点操作DOM树
    // # 解析XML文件并返回ElementTree对象
    DocumentBuilderFactory documentBuilderFactory =DocumentBuilderFactory.newDefaultInstance();
    try {
        DocumentBuilder db = documentBuilderFactory.newDocumentBuilder();
        Document document = db.parse("Order.xml");
        //user元素
        NodeList nodeList = document.getElementsByTagName("order");
        ArrayList<Order> orderArrayList = new ArrayList<>();
        for (int i = 0; i < nodeList.getLength(); i++) {
            //创建Meal对象
            Order order = new Order();
            //获取第i个user对象
            Node node = nodeList.item(i);
            //获取第i个user对象的属性值
            Element element = (Element) node;
            NodeList userNodeList = element.getChildNodes();
            for (int j = 0; j < userNodeList.getLength(); j++) {
                Node userNode = userNodeList.item(j);
                if (userNode.getNodeType() == Node.ELEMENT_NODE && userNode.getNodeName().equals("id")) {
                    Element userType = (Element) userNode;
                    order.setId(Integer.valueOf(userType.getAttribute("name")));
                }
                if (userNode.getNodeType() == Node.ELEMENT_NODE && userNode.getNodeName().equals("Uname")) {
                    Element userType = (Element) userNode;
                    order.setUname(userType.getAttribute("name"));
                }
                if (userNode.getNodeType() == Node.ELEMENT_NODE && userNode.getNodeName().equals("Mname")) {
                    Element userType = (Element) userNode;
                    order.setMname(userType.getAttribute("name"));
                }
                if (userNode.getNodeType() == Node.ELEMENT_NODE && userNode.getNodeName().equals("price")) {
                    Element userType = (Element) userNode;
                    order.setMoney(Double.valueOf(userType.getAttribute("name")));
                }
                if (userNode.getNodeType() == Node.ELEMENT_NODE && userNode.getNodeName().equals("state")) {
                    Element userType = (Element) userNode;
                    order.setState(userType.getAttribute("name"));
                }
            }
            orderArrayList.add(order);

        }
        //遍历
        for (Order order : orderArrayList) {
            System.out.println(order);
        }
    } catch (ParserConfigurationException e) {
        throw new RuntimeException(e);
    } catch (IOException e) {
        throw new RuntimeException(e);
    } catch (SAXException e) {
        throw new RuntimeException(e);
    }
}

public static void dele(){
    //读取user.xml文件
//    1.创建解析器工厂对象
//    2.解析器工厂对象创建解析器对象
//    3.解析器对象指定XML文件创建Document对象
//    4.以Document对象为起点操作DOM树
    // # 解析XML文件并返回ElementTree对象
    check();
    Scanner scanner=new Scanner(System.in);
    int id=scanner.nextInt();
    DocumentBuilderFactory documentBuilderFactory =DocumentBuilderFactory.newDefaultInstance();
    try {
        DocumentBuilder db =documentBuilderFactory.newDocumentBuilder();
        Document document =db.parse("Order.xml");
        //user元素

        NodeList nodeList =document.getElementsByTagName("order");
        for(int i=0;i<nodeList.getLength();i++){
            //获取第i个user对象
            Element node =(Element) nodeList.item(i);
            //获取第i个user对象的属性值
            Element element =(Element) node;
            NodeList userNodeList = element.getChildNodes();
            for(int j=0;j<userNodeList.getLength();j++){
                Element userNode = (Element) userNodeList.item(j);
                if(userNode.getNodeType()==Node.ELEMENT_NODE&&userNode.getNodeName().equals("id")){
                    Element userType =(Element) userNode;
                    if(id==Integer.valueOf(userType.getAttribute("name"))){
                        node.getParentNode().removeChild(userNode);
                    }
                }
            }
        }
        //保存xml文件
        TransformerFactory transformerFactory =TransformerFactory.newInstance();
        Transformer transformer =transformerFactory.newTransformer();
        DOMSource docSourse =  new DOMSource(document);
        //设置编码类型
        transformer.setOutputProperty(OutputKeys.ENCODING,"utf-8");
        StreamResult result =new StreamResult(new FileOutputStream("Order.xml"));
        transformer.transform(docSourse,result);

    } catch (ParserConfigurationException e) {
        throw new RuntimeException(e);
    } catch (IOException e) {
        throw new RuntimeException(e);
    } catch (SAXException e) {
        throw new RuntimeException(e);
    } catch (TransformerConfigurationException e) {
        throw new RuntimeException(e);
    } catch (TransformerException e) {
        throw new RuntimeException(e);
    }
}

public static void sign(){
    //读取user.xml文件
//    1.创建解析器工厂对象
//    2.解析器工厂对象创建解析器对象
//    3.解析器对象指定XML文件创建Document对象
//    4.以Document对象为起点操作DOM树
    // # 解析XML文件并返回ElementTree对象
    DocumentBuilderFactory documentBuilderFactory =DocumentBuilderFactory.newDefaultInstance();
    try {
        DocumentBuilder db =documentBuilderFactory.newDocumentBuilder();
        Document document =db.parse("Order.xml");
        //user元素
        NodeList nodeList =document.getElementsByTagName("order");
        for(int i=0;i<nodeList.getLength();i++){
            //获取第i个user对象
            Node node =nodeList.item(i);
            //获取第i个user对象的属性值
            Element element =(Element) node;
            NodeList userNodeList = element.getChildNodes();
            for(int j=0;j<userNodeList.getLength();j++){
                Node userNode = userNodeList.item(j);
                if(userNode.getNodeType()==Node.ELEMENT_NODE&&userNode.getNodeName().equals("state")){
                    Element userType =(Element) userNode;
                    userType.setAttribute("state","已完成");
                }
            }
        }
        //保存xml文件
        TransformerFactory transformerFactory =TransformerFactory.newInstance();
        Transformer transformer =transformerFactory.newTransformer();
        DOMSource docSourse =  new DOMSource(document);
        //设置编码类型
        transformer.setOutputProperty(OutputKeys.ENCODING,"utf-8");
        StreamResult result =new StreamResult(new FileOutputStream("Order.xml"));
        transformer.transform(docSourse,result);

    } catch (ParserConfigurationException e) {
        throw new RuntimeException(e);
    } catch (IOException e) {
        throw new RuntimeException(e);
    } catch (SAXException e) {
        throw new RuntimeException(e);
    } catch (TransformerConfigurationException e) {
        throw new RuntimeException(e);
    } catch (TransformerException e) {
        throw new RuntimeException(e);
    }
}

public static void like(){
    //读取user.xml文件
//    1.创建解析器工厂对象
//    2.解析器工厂对象创建解析器对象
//    3.解析器对象指定XML文件创建Document对象
//    4.以Document对象为起点操作DOM树
    // # 解析XML文件并返回ElementTree对象
    Scanner scanner =new Scanner(System.in);
    System.out.println("要点赞的订单");
    int id = scanner.nextInt();
    boolean flag =false;
    String name =null;
    DocumentBuilderFactory documentBuilderFactory =DocumentBuilderFactory.newDefaultInstance();
    try {
        DocumentBuilder db =documentBuilderFactory.newDocumentBuilder();
        Document document =db.parse("Order.xml");
        //user元素
        NodeList nodeList =document.getElementsByTagName("order");
        for(int i=0;i<nodeList.getLength();i++){
            flag=true;
            //获取第i个user对象
            Node node =nodeList.item(i);
            //获取第i个user对象的属性值
            Element element =(Element) node;
            NodeList userNodeList = element.getChildNodes();
            for(int j=0;j<userNodeList.getLength();j++){
                Node userNode = userNodeList.item(j);
                if(userNode.getNodeType()==Node.ELEMENT_NODE&&userNode.getNodeName().equals("id")){
                    Element userType =(Element) userNode;
                    if(id==Integer.valueOf(userType.getAttribute("name"))){
                        flag=false;
                    }
                }
                if(userNode.getNodeType()==Node.ELEMENT_NODE&&userNode.getNodeName().equals("name")&&!flag){
                    Element userType =(Element) userNode;
                        name=userType.getAttribute("name");
                }
            }
        }

        Document doc =db.parse("Meal.xml");
        //user元素
        NodeList list =document.getElementsByTagName("meal");
        for(int i=0;i<list.getLength();i++){
            //获取第i个user对象
            Node node =list.item(i);
            //获取第i个user对象的属性值
            Element element =(Element) node;
            NodeList userNodeList = element.getChildNodes();
            for(int j=0;j<userNodeList.getLength();j++){
                Node userNode = userNodeList.item(j);
                if(userNode.getNodeType()==Node.ELEMENT_NODE&&userNode.getNodeName().equals("likes")){
                    Element userType =(Element) userNode;
                    userType.setAttribute("likes",userType.getAttribute("name")+1);
                }
            }
        }
        //保存xml文件
        TransformerFactory transformerFactory =TransformerFactory.newInstance();
        Transformer transformer =transformerFactory.newTransformer();
        DOMSource docSourse =  new DOMSource(document);
        //设置编码类型
        transformer.setOutputProperty(OutputKeys.ENCODING,"utf-8");
        StreamResult result =new StreamResult(new FileOutputStream("Order.xml"));
        transformer.transform(docSourse,result);
    } catch (ParserConfigurationException e) {
        throw new RuntimeException(e);
    } catch (IOException e) {
        throw new RuntimeException(e);
    } catch (SAXException e) {
        throw new RuntimeException(e);
    } catch (TransformerConfigurationException e) {
        throw new RuntimeException(e);
    } catch (TransformerException e) {
        throw new RuntimeException(e);
    }
}
}
