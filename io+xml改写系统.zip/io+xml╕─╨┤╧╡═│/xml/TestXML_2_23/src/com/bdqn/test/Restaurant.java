package com.bdqn.test;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Restaurant {
/**
 * @author liuziyang
 * @data 2024-02-23-17:08
 */
public static void login(){
    //读取user.xml文件
//    1.创建解析器工厂对象
//    2.解析器工厂对象创建解析器对象
//    3.解析器对象指定XML文件创建Document对象
//    4.以Document对象为起点操作DOM树
    // # 解析XML文件并返回ElementTree对象
    DocumentBuilderFactory documentBuilderFactory =DocumentBuilderFactory.newDefaultInstance();
    User user = null;
    try {
        Scanner scanner =new Scanner(System.in);
        System.out.print("输入用户名: ");
        String root =scanner.next();
        System.out.print("输入密码: ");
        String pwd = scanner.next();
        DocumentBuilder db =documentBuilderFactory.newDocumentBuilder();
        Document document =db.parse("User.xml");
        NodeList usersNodeList =document.getElementsByTagName("user");
        boolean rootFlag =false;
        boolean pwdFlag =false;
        //获取孩子中root 的name属性
        for(int i=0;i<usersNodeList.getLength();i++){
            //获取第i个user元素
            Node userNode = usersNodeList.item(i);
            //获取全部孩子
            rootFlag =false;
            pwdFlag =false;
            NodeList userTypes = userNode.getChildNodes();
            for(int j=0;j<userTypes.getLength();j++){
                //获取对应name属性
                Node type =userTypes.item(i);
                if(type.getNodeType()==Node.ELEMENT_NODE&&type.getNodeName().equals("root")){
                    Element eleType =(Element) type;
                    if(root.equals(eleType.getAttribute("name"))){
                        //如果相同 比较密码
                        rootFlag=true;
                    }
                    user.setRoot(eleType.getAttribute("name"));
                }
                if(type.getNodeType()==Node.ELEMENT_NODE&&type.getNodeName().equals("pwd")){
                    Element eleType =(Element) type;
                    if(pwd.equals(eleType.getAttribute("name"))){
                        //如果相同 比较密码
                        pwdFlag=true;
                    }
                    user.setPwd(eleType.getAttribute("name"));
                }
                if(type.getNodeType()==Node.ELEMENT_NODE&&type.getNodeName().equals("name")){
                    Element eleType =(Element) type;
                    user.setName(eleType.getAttribute("name"));
                }
                if(type.getNodeType()==Node.ELEMENT_NODE&&type.getNodeName().equals("adder")){
                    Element eleType =(Element) type;
                    user.setAdder(eleType.getAttribute("name"));
                }
            }

        }
        if(pwdFlag&&rootFlag){
            //说明匹配成功
            int input;
            do {
                //进入子菜单
                Mean.submenu();
                System.out.print("请输入你的选择: ");
                input=scanner.nextInt();
                switch (input){
                    case 0:
                        return;
                    case 1:Mean.orderFoot(user); //订餐
                        break;
                    case 2:Mean.check();//查看订单
                        break;
                    case 3:Mean.sign();//签收订单
                        break;
                    case 4:Mean.dele();//删除订单
                        break;
                    case 5:Mean.like();//点赞餐品
                        break;
                    default:
                        System.out.println("选择错误，重新选择");
                        break;

                }
            }while (input!=0);
        }else{
            System.out.println("用户名或者密码错误");
        }
    } catch (ParserConfigurationException e) {
        throw new RuntimeException(e);
    } catch (IOException e) {
        throw new RuntimeException(e);
    } catch (SAXException e) {
        throw new RuntimeException(e);
    }

}
public static void enroll(){
    //读取user.xml文件
//    1.创建解析器工厂对象
//    2.解析器工厂对象创建解析器对象
//    3.解析器对象指定XML文件创建Document对象
//    4.以Document对象为起点操作DOM树
   // # 解析XML文件并返回ElementTree对象
    DocumentBuilderFactory documentBuilderFactory =DocumentBuilderFactory.newDefaultInstance();
    try {
        Scanner scanner =new Scanner(System.in);
        System.out.print("输入用户名: ");
        String root =scanner.next();
        DocumentBuilder db =documentBuilderFactory.newDocumentBuilder();
        Document document =db.parse("User.xml");
        NodeList usersNodeList =document.getElementsByTagName("user");
        //获取孩子中root 的name属性
        for(int i=0;i<usersNodeList.getLength();i++){
            //获取第i个user元素
            Node userNode = usersNodeList.item(i);
            //获取全部孩子
            NodeList userTypes = userNode.getChildNodes();
            for(int j=0;j<userTypes.getLength();j++){
                //获取对应name属性
                Node type =userTypes.item(i);
                if(type.getNodeType()==Node.ELEMENT_NODE&&type.getNodeName().equals("root")){
                    Element eleType =(Element) type;
                    if(root.equals(eleType.getAttribute("name"))){
                        //如果相同 因为用户名唯一 结束
                        System.out.println("用户名已存在");
                        return;
                    }
                }
            }
        }
        System.out.print("输入密码: ");
        String pwd = scanner.next();
        System.out.print("输入用户名称: ");
        String name = scanner.next();
        System.out.print("输入地址: ");
        String adder = scanner.next();
        //创建用户节点
        Element brandElement =document.createElement("user");
        //创建user的孩子节点
        Element rootElement =document.createElement("root");
        rootElement.setAttribute("name",root);
        Element pwdElement =document.createElement("pwd");
        rootElement.setAttribute("name",pwd);
        Element nameElement =document.createElement("name");
        rootElement.setAttribute("name",name);
        Element adderElement =document.createElement("adder");
        rootElement.setAttribute("name",adder);
        //添加父子关系
        brandElement.appendChild(rootElement);
        brandElement.appendChild(pwdElement);
        brandElement.appendChild(nameElement);
        brandElement.appendChild(adderElement);
        Element element =(Element)document.getElementsByTagName("users").item(0);
        element.appendChild(brandElement);
        //保存xml文件
        TransformerFactory transformerFactory =TransformerFactory.newInstance();
        Transformer transformer =transformerFactory.newTransformer();
        DOMSource docSourse =  new DOMSource(document);
        //设置编码类型
        transformer.setOutputProperty(OutputKeys.ENCODING,"utf-8");
        StreamResult result =new StreamResult(new FileOutputStream("User.xml"));
        transformer.transform(docSourse,result);
    } catch (ParserConfigurationException e) {
        throw new RuntimeException(e);
    } catch (IOException e) {
        throw new RuntimeException(e);
    } catch (SAXException e) {
        throw new RuntimeException(e);
    } catch (TransformerConfigurationException e) {
        throw new RuntimeException(e);
    } catch (TransformerException e) {
        throw new RuntimeException(e);
    }

}
}
