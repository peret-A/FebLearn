package com.bdqn.test;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
//实现Serializable序列化
public class Order implements Serializable {
/**
 * @author liuziyang
 * @data 2024-02-22-18:39
 */
private static final long SerializableUID = 1L;
//订单序号 订餐人名字 订单餐名 订餐份数 订餐状态 送餐时间 总金额
    private int id;
    private String Uname;
    private String Mname;
    private String state;
    private double money;

    @Override
    public String toString() {
        return "订单{" +
                "序号=" + id +
                ", 订餐人='" + Uname + '\'' +
                ", 餐名='" + Mname + '\'' +
                ", 餐费='" + money + '\'' +
                ", 状态='" + state +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUname() {
        return Uname;
    }

    public void setUname(String uname) {
        Uname = uname;
    }

    public String getMname() {
        return Mname;
    }

    public void setMname(String mname) {
        Mname = mname;
    }


    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }


    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public Order() {
    }

    public Order(int id, String uname, String mname, String state, double money) {
        this.id = id;
        Uname = uname;
        Mname = mname;
        this.state = state;
        this.money = money;
    }
}
