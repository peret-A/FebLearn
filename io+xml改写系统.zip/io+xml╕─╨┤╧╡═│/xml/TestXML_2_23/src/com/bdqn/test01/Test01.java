package com.bdqn.test01;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Test01 {
/**
 * @author liuziyang
 * @data 2024-02-23-19:34
 */
public static void main(String[] args) {
    try {
        DocumentBuilderFactory documentBuilderFactory =DocumentBuilderFactory.newInstance();
        DocumentBuilder db =documentBuilderFactory.newDocumentBuilder();
        Document document =db.parse("User.xml");
        //创建用户节点
        Element brandElement =document.createElement("user");
        //创建user的孩子节点
        Element rootElement =document.createElement("root");
        rootElement.setAttribute("name","root");
        Element pwdElement =document.createElement("pwd");
        pwdElement.setAttribute("name","123");
        Element nameElement =document.createElement("name");
        nameElement.setAttribute("name","张三");
        Element adderElement =document.createElement("adder");
        adderElement.setAttribute("name","1-11");
        //添加父子关系
        brandElement.appendChild(rootElement);
        brandElement.appendChild(pwdElement);
        brandElement.appendChild(nameElement);
        brandElement.appendChild(adderElement);

        Element user=(Element)document.getElementsByTagName("users").item(0);
        user.appendChild(brandElement);
        //保存xml文件
        TransformerFactory transformerFactory =TransformerFactory.newInstance();
        Transformer transformer =transformerFactory.newTransformer();
        DOMSource docSourse =  new DOMSource(document);
        //设置编码类型
        transformer.setOutputProperty(OutputKeys.ENCODING,"utf-8");
        StreamResult result =new StreamResult(new FileOutputStream("User.xml"));
        transformer.transform(docSourse,result);
    } catch (ParserConfigurationException e) {
        throw new RuntimeException(e);
    } catch (IOException e) {
        throw new RuntimeException(e);
    } catch (SAXException e) {
        throw new RuntimeException(e);
    } catch (TransformerConfigurationException e) {
        throw new RuntimeException(e);
    } catch (TransformerException e) {
        throw new RuntimeException(e);
    }
}
}
