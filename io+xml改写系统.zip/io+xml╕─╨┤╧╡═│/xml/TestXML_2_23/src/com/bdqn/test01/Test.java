package com.bdqn.test01;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

public class Test {
/**
 * @author liuziyang
 * @data 2024-02-23-18:23
 */
public static void main(String[] args) {
    //读取user.xml文件
//    1.创建解析器工厂对象
//    2.解析器工厂对象创建解析器对象
//    3.解析器对象指定XML文件创建Document对象
//    4.以Document对象为起点操作DOM树
    // # 解析XML文件并返回ElementTree对象
    DocumentBuilderFactory documentBuilderFactory =DocumentBuilderFactory.newDefaultInstance();
    try {
        DocumentBuilder db =documentBuilderFactory.newDocumentBuilder();
        Document document =db.parse("User.xml");
        //user元素
        NodeList nodeList =document.getElementsByTagName("user");
        for(int i=0;i<nodeList.getLength();i++){
            //获取第i个user对象
            Node node =nodeList.item(i);
            //获取第i个user对象的属性值
            Element element =(Element) node;
            NodeList userNodeList = element.getChildNodes();
            for(int j=0;j<userNodeList.getLength();j++){
                Node userNode = userNodeList.item(j);
                if(userNode.getNodeType()==Node.ELEMENT_NODE){
                    Element userType =(Element) userNode;
                    System.out.println(userType.getAttribute("name"));
                }
            }
        }

    } catch (ParserConfigurationException e) {
        throw new RuntimeException(e);
    } catch (IOException e) {
        throw new RuntimeException(e);
    } catch (SAXException e) {
        throw new RuntimeException(e);
    }
}
}
